package com.example.ajare_v2;

import androidx.appcompat.app.AppCompatActivity;

public class InformationClient extends AppCompatActivity {
}
