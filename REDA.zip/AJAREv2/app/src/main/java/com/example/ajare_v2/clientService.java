package com.example.ajare_v2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class clientService extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_service);
    }
}