package com.example.ajare_v2;

import android.app.Instrumentation;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import static androidx.test.InstrumentationRegistry.getInstrumentation;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
@LargeTest
public class ManageAccActivityTest {
    @Rule
    public ActivityTestRule<ManageAccActivity> mActivityTestRule= new ActivityTestRule<ManageAccActivity>(ManageAccActivity.class);
    private ManageAccActivity manageAccActivity = null;
    private final FirebaseAuth auth=FirebaseAuth.getInstance();
    private static final String email ="admin@novigrad.com";
    private static  String password = "1234567";
    @Before
    public void setUp()  {
        manageAccActivity = mActivityTestRule.getActivity();
    }
    @Test (expected=  FirebaseAuthInvalidUserException.class)
    public void deleteAcc(){


    }
    @After
    public void tearDown()  {
        manageAccActivity = null;
    }
}