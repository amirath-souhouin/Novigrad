package com.example.ajare_v2;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Main_Nav extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_nav);

    }

}