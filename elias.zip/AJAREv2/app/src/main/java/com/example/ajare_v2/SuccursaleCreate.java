package com.example.ajare_v2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.intellij.lang.annotations.RegExp;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.example.ajare_v2.CreateActivity.emailIsValid;

public class SuccursaleCreate extends AppCompatActivity {
    Button schedules;
    EditText courriel;
    EditText address;
    EditText numero;
    EditText password;
    Button createAccount;
    String horaire = "";
    TextView horaireDisplay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_succursale_create);
        schedules = (Button) findViewById(R.id.schedules);
        courriel = (EditText) findViewById(R.id.emailedit);
        address = (EditText) findViewById(R.id.adressedit);
        numero = (EditText) findViewById(R.id.editTextPhone);
        password = (EditText) findViewById(R.id.passwordedit);
        createAccount = (Button) findViewById(R.id.create);
        horaireDisplay = (TextView) findViewById(R.id.horaire) ;
        schedules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SuccursaleCreate.this, Schedule.class));
            }
        });
        Intent intent = getIntent();
        if (intent!=null){

            if(intent.hasExtra("Horaire")){
                horaire = intent.getStringExtra("Horaire");
            }
        }
        Succursale succursale = new Succursale();
        succursale.setAddresseName(address.getText().toString());
        succursale.setEmail(courriel.getText().toString());
        succursale.setNumero(numero.getText().toString());
        succursale.setPassword(password.getText().toString());
        succursale.setHoraire(horaire);
        horaireDisplay.setText(horaire);
        /*createAccount.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String mail = courriel.getText().toString();
                String zipCode = address.getText().toString();
                String number = numero.getText().toString();
                if(!emailIsValid(mail)){
                    courriel.setError("Please enter a valid email address.");
                    courriel.requestFocus();
                }
                else if(!addressIsValid(zipCode)) {
                    Toast.makeText(SuccursaleCreate.this, "The address must be in the form A1A 1A1 or A1A1A1", Toast.LENGTH_SHORT).show();
                } else if (!numberIsValid(number)) {
                    Toast.makeText(SuccursaleCreate.this, "The phone number must be in the form XXX-XXX-XXXX", Toast.LENGTH_SHORT).show();
                }
                else {

                }
            }
        });*/
    }

    public static boolean numberIsValid(String number) {
        Pattern pattern = Pattern.compile("\\d{3}-\\d{3}-\\d{4}");
        Matcher matcher = pattern.matcher(number);

        if (matcher.matches()){
            return true;
        }
        else{
            return false;
        }
    }
    public static boolean firstLetterPostalCode(String postal){
        for(char c :"DFIOQUWZ".toCharArray()){
            if(postal.charAt(0)== c){
                return false;
            }
        }
        return true;
    }
    public static boolean addressIsValid(String postalCode) {
                //DFIOQUWZ
            String postal = "T1A 1B1";

            if(postal.length() == 7) {
                if ((postal.length()== 0)
                        || (!Character.isLetter(postal.charAt(0)) && !firstLetterPostalCode(postalCode))
                        || (!Character.isDigit(postal.charAt(1)))
                        || (!Character.isLetter(postal.charAt(2)))
                        || (!Character.isWhitespace(postal.charAt(3)))
                        || (!Character.isDigit(postal.charAt(4)))
                        || (!Character.isLetter(postal.charAt(5)))
                        || (!Character.isDigit(postal.charAt(6))))
                {
                    System.out.println("7It is not the same");
                    return  false;
                }
                else
                {
                    System.out.println("7It is the same");
                    return  true;
                }
            } else if(postal.length() == 6) {
                if ((postal.length()== 0)
                        || (!Character.isLetter(postal.charAt(0))&& !firstLetterPostalCode(postalCode))
                        || (!Character.isDigit(postal.charAt(1)))
                        || (!Character.isLetter(postal.charAt(2)))
                        || (!Character.isDigit(postal.charAt(3)))
                        || (!Character.isLetter(postal.charAt(4)))
                        || (!Character.isDigit(postal.charAt(5))))
                {
                    System.out.println("6It is not the same");
                    return  false;
                }
                else
                {
                    System.out.println("6It is the same");
                    return true;
                }

            }
        return false;
    }


}